package com.yahav.coupons;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CouponsManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
