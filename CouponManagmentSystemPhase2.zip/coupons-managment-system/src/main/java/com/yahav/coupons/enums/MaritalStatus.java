package com.yahav.coupons.enums;

public enum MaritalStatus {
    SINGLE,
    MARRIED,
    WIDOWED,
    DIVORCED,
    UNKNOWN
}
