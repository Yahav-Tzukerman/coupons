package com.yahav.coupons.enums;

public enum Gender {
    MALE,
    FEMALE,
    TRANSGENDER,
    AGENDER,
    UNKNOWN
}
