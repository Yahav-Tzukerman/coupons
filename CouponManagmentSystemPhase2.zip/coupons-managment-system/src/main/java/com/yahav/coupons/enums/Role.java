package com.yahav.coupons.enums;

public enum Role {
    ADMIN,
    COMPANY,
    CUSTOMER
}
