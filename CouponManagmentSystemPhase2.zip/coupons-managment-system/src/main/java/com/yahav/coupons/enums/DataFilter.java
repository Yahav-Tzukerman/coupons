package com.yahav.coupons.enums;

public enum DataFilter {
    BY_CATEGORY,
    BY_MAX_PRICE,
    BY_COMPANY,
    SEARCH_BY_TITLE
}
